#ifndef  __T1_H
#define __T1_H

#include <stdio.h>
#include <stdlib.h>


int myprintf();
















#endif // !