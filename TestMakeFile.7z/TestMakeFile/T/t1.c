#include "t1.h"



int myprintf()
{
    printf("hello world \r\n");
}







