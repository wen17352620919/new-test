#include <stdio.h>
#include <stdlib.h>

#include "T/t1.h"

#include "A/a1.h"


int main()
{
    __uint8_t a =0;
    printf("a=%d\n",a);
    myprintf();
    testa1();
}















