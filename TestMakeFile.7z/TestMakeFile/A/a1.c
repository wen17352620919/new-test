#include "a1.h"

void testa1()
{
    printf("a1.h\r\n");
}