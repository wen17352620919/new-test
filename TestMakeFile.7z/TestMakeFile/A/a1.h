#ifndef  __A1_H
#define __A1_H

#include <stdio.h>
#include <stdlib.h>


void testa1();


#endif // ! 